package com.example.enzo.test;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.Socket;

import fr.masterdapm.ancyen.model.User;

import static android.content.ContentValues.TAG;

/* This class represents the entry point of the application. It allows a user to sign in or sign up.
In its arttibutes, it has a private class of AsynTask type. Thanks to it, we can connect to the server in a non blocking way.
The server will query the database and will send back a return code to the client.

 */





public class MainActivity extends AppCompatActivity {

    private static final String TAG = "numero";
    Button connexion;
    Button test;
    EditText email;
    EditText password;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        connexion = (Button) findViewById(R.id.boutonconnexion);


        email = (EditText) findViewById(R.id.editmail);

        password = (EditText) findViewById(R.id.editmdp);

    }





    public void connexiontoprofile(View v) {
        //We start a connexion with the server thanks to the AsynConnection class when clicking on the button.

        new ASyncConnection().execute();



    }


    //We start the sign up activity when this button is clicked.
    public void inscription(View v) {


        Intent intentapp = new Intent(MainActivity.this, Inscrire.class);
        MainActivity.this.startActivity(intentapp);


    }





    private class ASyncConnection extends AsyncTask<Void, Void, Integer> {


    //We create a thread, detached from the application. We get a connexion to the server thanks to the getInstance method
        // which guarantees a singleton in order to not create again new connexions if an instance already exists.

        @Override
        protected Integer doInBackground(Void... params) {
            Integer i = 0;
            Connection connection = Connection.getInstance();


            try {
                connection.oos.writeObject("checkUser");
                connection.oos.writeObject(email.getText().toString());
                connection.oos.writeObject(password.getText().toString());
                i = (Integer) connection.ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            try {
                connection.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return i;
        }
    /* The onPostExecute method starts when the doInBackground method ends.
    In this case, we test if the user exists in the database, and we start a new activity, Account.
*/

        @Override
        protected void onPostExecute(Integer integer) {
            if (integer == 1) {
                Intent intent = new Intent(MainActivity.this, Account.class);
                intent.putExtra("mail_user", email.getText().toString());

                startActivity(intent);
            }
        }

        @Override
        protected void onProgressUpdate(Void... values) {

        }
    }




}
