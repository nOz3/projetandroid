package com.example.enzo.test;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.maps.android.ui.IconGenerator;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import fr.masterdapm.ancyen.model.Position;
import fr.masterdapm.ancyen.model.Ride;
import fr.masterdapm.ancyen.model.Statistics;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationRequest locationRequest;
    private LocationCallback locationCallback;
    private LocationSettingsRequest.Builder builder;
    private SettingsClient client;
    private Task<LocationSettingsResponse> task;

    private Intent intent;
    String mail_user;
    int idRide;

    private Polyline activeLine;
    private List <Marker> markers = new ArrayList<>();
    private List<LatLng> myWay = new ArrayList<>();
    private boolean isMe = true;
    public static final int REQUEST_LOCATION = 199;

    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

         intent = getIntent();

        Bundle bd = intent.getExtras();

        if(bd != null){

            mail_user = (String) bd.get("mail_user");
            idRide = (int) bd.get("idRide");



        }



        // Obtain the SupportMapFragment and get notified when the map is ready to be used.

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        locationRequest = new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        builder = new LocationSettingsRequest.Builder().addLocationRequest(locationRequest);

        client = LocationServices.getSettingsClient(this);

        task = client.checkLocationSettings(builder.build());

        progressBar = findViewById(R.id.pb);

        intent = new Intent(MapsActivity.this, CameraPreview.class);

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                Log.e("lolmdr", "avant callback");
                for (Location location : locationResult.getLocations()) {

                    double alt = location.getAltitude();
                    progressBar.setProgress((int) alt);
                    LatLng pos = new LatLng(location.getLatitude(), location.getLongitude());
                    myWay.add(pos);
                    // TODO: Stocker les positions dans BD.
                    Log.e("lolmdr", "5secondes");
                   new ASyncConnection().execute(idRide, mail_user, pos.longitude, pos.latitude);
                }
                if (isMe) displayPath(myWay);
            }
        };
    }

    @Override
    public void onResume() {
        super.onResume();
        checkPermission();
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setIndoorEnabled(false);
        mMap.getUiSettings().setIndoorLevelPickerEnabled(false);
        mMap.getUiSettings().setMyLocationButtonEnabled(true);



        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {
                startActivity(intent);
            }
        });

        activeLine = mMap.addPolyline(new PolylineOptions());

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                removePath();
                isMe = false;
//                displayPath(markerPath);
                return false;
            }
        });

        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                startLocation();
            }
        });

        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                int statuscode = ((ApiException)e).getStatusCode();
                switch (statuscode){
                    case CommonStatusCodes.RESOLUTION_REQUIRED:
                        try {
                            ResolvableApiException resolvable = (ResolvableApiException) e;
                            resolvable.startResolutionForResult(MapsActivity.this,
                                    REQUEST_LOCATION);
                        }
                        catch (IntentSender.SendIntentException sendEx){
                        }
                        break;
                    case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                        break;
                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data){
        if (requestCode == REQUEST_LOCATION){
            switch (resultCode) {
                case Activity.RESULT_OK:
                    Toast.makeText(MapsActivity.this,
                            "Location enabled by user!", Toast.LENGTH_LONG).show();
                    startLocation();
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(MapsActivity.this,
                            "Location not enabled, user cancelled.", Toast.LENGTH_LONG).show();
                    break;
                default:
                    break;
            }
        }
    }

    public void startLocation(){
        checkPermission();
        mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
        Log.e("lolmdr", "avant localisation");
        mMap.setMyLocationEnabled(true);
        Log.e("lolmdr", "apres localisation");
        mMap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
            @Override
            public boolean onMyLocationButtonClick() {
                isMe = true;
                return false;
            }
        });
    }

    public void checkPermission(){
        if (ActivityCompat.checkSelfPermission(MapsActivity.this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MapsActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION);
        }
    }

    public void createMarkers(List<LatLng> latLngs){
        for (LatLng pos:latLngs) {
            TextView name = new TextView(MapsActivity.this);
            name.setText("Moi lol");
            IconGenerator icon = new IconGenerator(MapsActivity.this);
            icon.setColor(Color.parseColor("red"));
            icon.setContentView(name);
            markers.add(mMap.addMarker(new MarkerOptions().position(pos)
                    .icon(BitmapDescriptorFactory.fromBitmap(icon.makeIcon()))));
        }
    }

    private void replaceMarkers(List<LatLng> latLngs){
        for (int i = 0; i < latLngs.size() ; i++) {
            markers.get(i).setPosition(latLngs.get(i));
        }
    }

    public void displayPath(List<LatLng> latLngs){
        activeLine.setPoints(latLngs);
    }

    public void displayMainPath(List<LatLng> latLngs){
        mMap.addPolyline(new PolylineOptions().color(Color.MAGENTA));
    }

    public void removePath(){
        activeLine.remove();
    }

    public void showAlt(View view) {
        Toast.makeText(MapsActivity.this, Integer.toString(progressBar.getProgress()), Toast.LENGTH_LONG).show();
    }


    private class ASyncConnection extends AsyncTask<Object, Void, Void> {




        @Override
        protected Void doInBackground(Object... params) {

            Connection connection = Connection.getInstance();
            int idRide = (Integer) params[0];
            String mail_user = (String) params[1];
            double longitude = (Double) params[2];
            double latitude = (Double) params[3];


            try {
                connection.oos.writeObject("updateStatistics");
                connection.oos.writeObject(idRide);
                connection.oos.writeObject(mail_user);
                connection.oos.writeObject(longitude);
                connection.oos.writeObject(latitude);
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                connection.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }



        @Override
        protected void onPostExecute(Void result) {
            Log.e("lolmdr", "Postexecute");



        }

        @Override
        protected void onProgressUpdate(Void... values) {

        }

        @Override
        protected void onPreExecute() {
            Log.e("lolmdr", "preexecute");
        }
    }


    private class ASyncConnectionRide extends AsyncTask<Integer, Void, Ride> {




        @Override
        protected Ride doInBackground(Integer... params) {

            Connection connection = Connection.getInstance();
            int idRide = (Integer) params[0];


            Ride ride = null;
            try {
                connection.oos.writeObject("getRide");
                connection.oos.writeObject(idRide);
                ride = (Ride) connection.ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            try {
                connection.client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return ride;
        }



        @Override
        protected void onPostExecute(Ride ride) {
            Position[] pos = ride.getPositions();
            List<LatLng> mainPath = new ArrayList<>();
            for (Position position:pos) {
                mainPath.add(new LatLng(position.getLatitude(), position.getLongitude()));
            }
            displayMainPath(mainPath);
        }

        @Override
        protected void onProgressUpdate(Void... values) {

        }

        @Override
        protected void onPreExecute() {
            Log.e("lolmdr", "preexecute");
        }
    }


}
